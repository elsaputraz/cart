@extends('layouts.template')
@section('content')
<div class="container">
  <div class="row">
    <div class="col col-md-8">
      @if(count($errors) > 0)
      @foreach($errors->all() as $error)
          <div class="alert alert-warning">{{ $error }}</div>
      @endforeach
      @endif
      @if ($message = Session::get('error'))
          <div class="alert alert-warning">
              <p>{{ $message }}</p>
          </div>
      @endif
      @if ($message = Session::get('success'))
          <div class="alert alert-success">
              <p>{{ $message }}</p>
          </div>
      @endif
      <div class="card">
        <div class="card-header">
          Item
        </div>
        <div class="card-body">
          <table class="table table-stripped">
            <thead>
              <tr>
                <th>No</th>
                <th>Produk</th>
                <th>Harga</th>
                <th>Diskon</th>
                <th>Qty</th>
                <th>Subtotal</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              @foreach($itemcart->detail as $detail)
              <tr>
                <td>
                {{ $no++ }}
                </td>
                <td>
                {{ $detail->produk->nama_produk }}
                <br />
                {{ $detail->produk->kode_produk }}
                </td>
                <td>
                {{ number_format($detail->harga, 2) }}
                </td>
                <td>
                {{ number_format($detail->diskon, 2) }}
                </td>
                <td>
                  <div class="btn-group" role="group">
                    <form action="{{ route('cartdetail.update',$detail->id) }}" method="post">
                    @method('patch')
                    @csrf()
                      <input type="hidden" name="param" value="kurang">
                      <button class="btn btn-primary btn-sm">
                      -
                      </button>
                    </form>
                    <button class="btn btn-outline-primary btn-sm" disabled="true">
                    {{ number_format($detail->qty, 2) }}
                    </button>
                    <form action="{{ route('cartdetail.update',$detail->id) }}" method="post">
                    @method('patch')
                    @csrf()
                      <input type="hidden" name="param" value="tambah">
                      <button class="btn btn-primary btn-sm">
                      +
                      </button>
                    </form>
                  </div>
                </td>
                <td>
                {{ number_format($detail->subtotal, 2) }}
                </td>
                <td>
                <form action="{{ route('cartdetail.destroy', $detail->id) }}" method="post" style="display:inline;">
                  @csrf
                  {{ method_field('delete') }}
                  <button type="submit" class="btn btn-sm btn-danger mb-2">
                    Hapus
                  </button>                    
                </form>
                </td>
              </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="col col-md-4">
      <div class="card">
        <div class="card-header">
          Ringkasan
        </div>
        <div class="card-body">
          <table class="table">
            <tr>
              <td>No Invoice</td>
              <td class="text-right">
                {{ $itemcart->no_invoice }}
              </td>
            </tr>
            <tr>
              <td>Subtotal</td>
              <td class="text-right">
                {{ number_format($itemcart->subtotal, 2) }}
              </td>
            </tr>
            <tr>
              <td>Diskon <button class = "btn btn-primary btn-xs" id="open_voucher">Voucher</button></td>
              <td class="text-right">
                {{ number_format($itemcart->diskon, 2) }}
              </td>
            </tr>
            <tr>
              <td>Total</td>
              <td class="text-right" id="total_belanja">
                {{ number_format($itemcart->total, 2) }}
              </td>
            </tr>
          </table>
        </div>
        <div class="card-footer">
          <div class="row">
            <div class="col">
              <button class="btn btn-primary btn-block">Checkout</button>
            </div>
            <div class="col">
              <form action="{{ url('kosongkan').'/'.$itemcart->id }}" method="post">
                @method('patch')
                @csrf()
                <button type="submit" class="btn btn-danger btn-block">Kosongkan</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


@endsection


@section('js')
<div class="modal" id="modal_voucher" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Voucher</h5>
        <button type="button" class="close close_modal" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form>
      @method('patch')
                    @csrf()
      MASUKKAN KODE VOUCHER : <input type="text" name="inpt_voucher" id="inpt_voucher" class="form-control">
      @method('patch')
                    @csrf()  
    </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="check_voucher">Gunakan Voucher</button>
        <button type="button" class="btn btn-secondary close_modal" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>

  <script>
    $('#open_voucher').click(function(){
      $('#modal_voucher').show()
    })

    $('.close_modal').click(function(){
      $('#modal_voucher').hide()
    })

    // check voucher
    $.ajaxSetup({                            
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')                          
        } 
    });
    $('#check_voucher').click(function(){
      var kode_voucher = $('#inpt_voucher').val()
      var total_belanja = $('#total_belanja').text()
      let token   = "{{ csrf_token() }}"
      // alert(total_belanja)
      
      $.ajax({
        
        url: "{{ url('voucher/check_voucher') }}",
        type: "POST",
        data: {
          kode_voucher: kode_voucher,
          total_belanja:total_belanja
          },
        dataType: "json",
        success: function(response){
          if(response.status){
            alert(response.pesan)
          }else{
            console.log(response)
          }
          
        }
      })
    })


  </script>
@endsection