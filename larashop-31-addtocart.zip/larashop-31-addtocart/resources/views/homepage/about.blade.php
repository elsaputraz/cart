@extends('layouts.template')
@section('content')
<div class="container">
  <div class="row">
    <div class="col">
      <h1>Tentang Kami</h1>
    </div>
  </div>
</div>
@endsection