<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class voucher extends Controller
{
    /**
     * Store a new user.
     *
     * @param  Request  $request
     * @return Response
     */
    public function index(Request $request)
    {
        
    }

    public function check_voucher(Request $request){
        $kode_voucher = $request->input('kode_voucher');
        $total_belanja = preg_replace('/\D/', '',  substr($request->input('total_belanja'), 0, -3));

        $data_voucher = DB::table('voucer_diskon')->where('kode_voucher', $kode_voucher)->first();
        if(empty($data_voucher)){
            $msg = [
                'status' => false,
                'pesan' => 'voucher tidak ditemukan'
            ];
            echo json_encode($msg);die();
        }

        $get_pot = $data_voucher->value_voucher; //default nya rupiah
        // conver persen
        if($data_voucher->jenis_voucher == 1 ){
            // persen ubah nominal
            $get_pot = ((int)$data_voucher->value_voucher / (int)100 ) * $total_belanja;
        }

        $data_voucher_detail = DB::table('voucher_perproduk')->where('id_voucher', $data_voucher->id_voucher)->get();
        
        $id_pr_get_dis = [];
        if(!empty($data_voucher_detail)){
            foreach($data_voucher_detail as $key => $value){
                $dis_perproduk = DB::table('cart_detail')->join('produk', 'cart_detail.produk_id','=','produk.id')->where('produk_id', $value->id_produk)->first();
                if(!empty($dis_perproduk)){
                    $new_harga_pr = $dis_perproduk->harga - $data_voucher->value_voucher;
                    if($new_harga_pr < 1 ){
                        $new_harga_pr = 0;
                    }
                    $id_pr_get_dis = ['id_produk'=>$value->id_produk, 'harga_pr_new' =>$new_harga_pr ];
                }
            }
        }

        if($total_belanja >= $data_voucher->min_beli){
            
        }

        $total_bayar_new = $total_belanja - $get_pot;
        // check keranjang product ini ada tidak

        print_r("<pre>"); print_r($id_pr_get_dis); die(); 
        echo json_encode($data_voucher_detail);die();


    }
}
