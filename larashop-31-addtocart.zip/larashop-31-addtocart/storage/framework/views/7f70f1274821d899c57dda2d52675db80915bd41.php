<?php $__env->startSection('content'); ?>
<div class="container">
  <!-- kategori produk -->
  <div class="row mt-4">
    <div class="col col-md-12 col-sm-12 mb-4">
      <h2 class="text-center">Kategori Produk</h2>
    </div>
    <?php $__currentLoopData = $itemkategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- kategori pertama -->
    <div class="col-md-4">
      <div class="card mb-4 shadow-sm">
        <a href="<?php echo e(URL::to('kategori/'.$kategori->slug_kategori)); ?>">
          <?php if($kategori->foto != null): ?>
          <img src="<?php echo e(\Storage::url($kategori->foto)); ?>" alt="<?php echo e($kategori->nama_kategori); ?>" class="card-img-top">
          <?php else: ?>
          <img src="<?php echo e(asset('images/bag.jpg')); ?>" alt="<?php echo e($kategori->nama_kategori); ?>" class="card-img-top">
          <?php endif; ?>
        </a>
        <div class="card-body">
          <a href="<?php echo e(URL::to('kategori/'.$kategori->slug_kategori)); ?>" class="text-decoration-none">
            <p class="card-text"><?php echo e($kategori->nama_kategori); ?></p>
          </a>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <!-- end kategori produk -->
  <!-- produk Terbaru-->
  <div class="row mt-4">
    <div class="col col-md-12 col-sm-12 mb-4">
      <h2 class="text-center">Terbaru</h2>
    </div>
    <?php $__currentLoopData = $itemproduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- produk pertama -->
    <div class="col-md-4">
      <div class="card mb-4 shadow-sm">
        <a href="<?php echo e(URL::to('produk/'.$produk->slug_produk)); ?>">
          <?php if($produk->foto != null): ?>
          <img src="<?php echo e(\Storage::url($produk->foto)); ?>" alt="<?php echo e($produk->nama_produk); ?>" class="card-img-top">
          <?php else: ?>
          <img src="<?php echo e(asset('images/bag.jpg')); ?>" alt="<?php echo e($produk->nama_produk); ?>" class="card-img-top">
          <?php endif; ?>
        </a>
        <div class="card-body">
          <a href="<?php echo e(URL::to('produk/'.$produk->slug_produk )); ?>" class="text-decoration-none">
            <p class="card-text">
              <?php echo e($produk->nama_produk); ?>

            </p>
          </a>
          <div class="row mt-4">
            <div class="col">
              <button class="btn btn-light">
                <i class="far fa-heart"></i>
              </button>
            </div>
            <div class="col-auto">
              <p>
                Rp. <?php echo e(number_format($produk->harga, 2)); ?>

              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larashop-31-addtocart\resources\views/homepage/kategori.blade.php ENDPATH**/ ?>