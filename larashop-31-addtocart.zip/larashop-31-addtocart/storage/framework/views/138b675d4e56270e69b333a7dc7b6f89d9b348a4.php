<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row mt-4">
    <div class="col col-lg-8 col-md-8">
      <div id="carousel" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
        <?php $__currentLoopData = $itemproduk->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($index == 0): ?>
          <div class="carousel-item active">
              <img src="<?php echo e(\Storage::url($image->foto)); ?>" class="d-block w-100" alt="...">
          </div>
        <?php else: ?>
          <div class="carousel-item">
              <img src="<?php echo e(\Storage::url($image->foto)); ?>" class="d-block w-100" alt="...">
          </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
    </div>
    <!-- deskripsi produk -->
    <div class="col col-lg-4 col-md-4">
      <div class="row">
        <div class="col">
          <div class="card">
            <div class="card-body">
              <?php if(count($errors) > 0): ?>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="alert alert-warning"><?php echo e($error); ?></div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              <?php if($message = Session::get('error')): ?>
                  <div class="alert alert-warning">
                      <p><?php echo e($message); ?></p>
                  </div>
              <?php endif; ?>
              <?php if($message = Session::get('success')): ?>
                  <div class="alert alert-success">
                      <p><?php echo e($message); ?></p>
                  </div>
              <?php endif; ?>
              <span class="small"><?php echo e($itemproduk->kategori->nama_kategori); ?></span>
              <h5><?php echo e($itemproduk->nama_produk); ?></h5>
              <!-- cek apakah ada promo -->
              <?php if($itemproduk->promo != null): ?>
              <p>
                Rp. <del><?php echo e(number_format($itemproduk->promo->harga_awal, 2)); ?></del>
                <br />
                Rp. <?php echo e(number_format($itemproduk->promo->harga_akhir, 2)); ?>

              </p>
              <?php else: ?>
              <p>
                Rp. <?php echo e(number_format($itemproduk->harga, 2)); ?>

              </p>
              <?php endif; ?>
              <form action="<?php echo e(route('wishlist.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="produk_id" value=<?php echo e($itemproduk->id); ?>>
                <button type="submit" class="btn btn-sm btn-outline-secondary">
                <?php if(isset($itemwishlist) && $itemwishlist): ?>
                <i class="fas fa-heart"></i> Tambah ke wishlist
                <?php else: ?>
                <i class="far fa-heart"></i> Tambah ke wishlist
                <?php endif; ?>
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <div class="row mt-4">
        <div class="col">
          <div class="card">
            <div class="card-body">
            <form action="<?php echo e(route('cartdetail.store')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="produk_id" value=<?php echo e($itemproduk->id); ?>>
              <button class="btn btn-block btn-primary" type="submit">
              <i class="fa fa-shopping-cart"></i> Tambahkan Ke Keranjang
              </button>
            </form>
              <button class="btn btn-block btn-danger mt-4">
              <i class="fa fa-shopping-basket"></i> Beli Sekarang
              </button>
            </div>
            <div class="card-footer">
              <div class="row mt-4">
                <div class="col text-center">
                  <i class="fa fa-truck-moving"></i> 
                  <p>Pengiriman Cepat</p>
                </div>
                <div class="col text-center">
                  <i class="fa fa-calendar-week"></i> 
                  <p>Garansi 7 hari</p>
                </div>
                <div class="col text-center">
                  <i class="fa fa-money-bill"></i> 
                  <p>Pembayaran Aman</p>
                </div>
              </div>            
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row mt-4">
    <div class="col">
      <div class="card">
        <div class="card-header">
          Deskripsi
        </div>
        <div class="card-body">
          <?php echo e($itemproduk->deskripsi_produk); ?>

        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larashop-31-addtocart\resources\views/homepage/produkdetail.blade.php ENDPATH**/ ?>