<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col">
      <h1>Tentang Kami</h1>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larashop-31-addtocart\resources\views/homepage/about.blade.php ENDPATH**/ ?>