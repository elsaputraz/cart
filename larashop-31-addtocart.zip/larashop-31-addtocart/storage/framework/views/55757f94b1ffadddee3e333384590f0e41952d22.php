<div class="container">
  <div class="row">
    <div class="col">
      <hr />
      <p>&copy Copyright Toko Online Powered by Laravel - PT VADS Indonesia</p>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\larashop-31-addtocart\resources\views/layouts/footer.blade.php ENDPATH**/ ?>