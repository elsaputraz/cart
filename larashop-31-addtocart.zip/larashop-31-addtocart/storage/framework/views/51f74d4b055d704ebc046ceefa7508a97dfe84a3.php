<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Wishlist</h3>
        </div>
        <div class="card-body">
          <?php if($message = Session::get('error')): ?>
              <div class="alert alert-warning">
                  <p><?php echo e($message); ?></p>
              </div>
          <?php endif; ?>
          <?php if($message = Session::get('success')): ?>
              <div class="alert alert-success">
                  <p><?php echo e($message); ?></p>
              </div>
          <?php endif; ?>
          <div class="table-responsive">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Kode Produk</th>
                  <th>Nama Produk</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $itemwishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <?php echo e(++$no); ?>

                  </td>
                  <td>
                    <?php echo e($wish->produk->kode_produk); ?>

                  </td>
                  <td>
                    <?php echo e($wish->produk->nama_produk); ?>

                  </td>
                  <td>
                    <form action="<?php echo e(route('wishlist.destroy', $wish->id)); ?>" method="post" style="display:inline;">
                      <?php echo csrf_field(); ?>
                      <?php echo e(method_field('delete')); ?>

                      <button type="submit" class="btn btn-sm btn-danger mb-2">
                        Hapus
                      </button>                    
                    </form>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <?php echo e($itemwishlist->links()); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larashop-31-addtocart\resources\views/wishlist/index.blade.php ENDPATH**/ ?>